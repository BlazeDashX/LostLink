import { Ionicons } from "@expo/vector-icons";
import { StyleSheet, Text, TextInput, View } from "react-native";

import { COLORS, SPACING } from "@/constants/theme";

interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
}

export default function SearchBar({
  value,
  onChangeText,
  placeholder = "Search",
}: SearchBarProps) {
  const handleSearch = () => {
    if (!value.trim()) {
      alert("Search field cannot be empty");
      return;
    }
  };

  return (
    <View style={styles.container}>
      <Ionicons
        color={COLORS.textMuted}
        name="search-outline"
        size={20}
      />

      <TextInput
        autoCapitalize="none"
        onChangeText={onChangeText}
        onSubmitEditing={handleSearch}
        placeholder={placeholder}
        placeholderTextColor={COLORS.textMuted}
        style={styles.input}
        value={value}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    backgroundColor: COLORS.surface,
    borderColor: COLORS.border,
    borderRadius: 14,
    borderWidth: 1,
    flexDirection: "row",
    gap: SPACING.sm,
    marginHorizontal: SPACING.lg,
    marginVertical: SPACING.md,
    paddingHorizontal: SPACING.md,
  },

  input: {
    color: COLORS.text,
    flex: 1,
    fontSize: 15,
    paddingVertical: 12,
    outlineStyle: "none",
  } as any,
});